% Find closest point in the triangle
% { find closest point in the triangle
%   Input: dataset a, xyz coordinate of three vertexes of the triangle
%   Output: cloest point c_outputs with Nsample frame and corresonding minimal distance between a and c_outputs
% }
function  [c_outputs, distance] = FindClosestPoint(a, p, q, r)
    % define void arrays
    c_outputs = [];
    distance = [];
    % iterate each point in dataset a
    for i = 1:length(a)
        ai = a(i,:);
        c_output_ai = [];
        % for each triangle, compute coefficient using least squares
        for j = 1:length(p)
            B = (ai - p(j,:))';
            A = [(q(j,:)-p(j,:))', (r(j,:)-p(j,:))'];
            res = lsqr(A,B);
            lambda = res(1);
            mu = res(2);
            % calculate a temporary closest point c
            c = lambda * (q(j,:)-p(j,:)) + mu * (r(j,:)-p(j,:)) + p(j,:);
            % check if c lies within the triangle
            % if not, we need to find point on the boarder of the triangle
            if (lambda < 0)
                c_output = ProjectOnSegment(c,r(j,:),p(j,:));
            elseif (mu < 0)
                c_output = ProjectOnSegment(c,p(j,:),q(j,:));
            elseif (lambda + mu > 1)
                c_output = ProjectOnSegment(c,q(j,:),r(j,:));
            else
                c_output = c;
            end
            c_output_ai = [c_output_ai;c_output];
        end
        % compute distance between a and closest points found in all triangles
        dist = [];
        for k = 1:length(c_output_ai)
            dist = [dist; norm(ai - c_output_ai(k,:))];
        end
        % find minimal distance and corresonding closest point
        index = find(dist == min(dist));
        c_output1 = c_output_ai(index,:);
        c_outputs = [c_outputs;c_output1];
        distance = [distance; min(dist)];
    end
end