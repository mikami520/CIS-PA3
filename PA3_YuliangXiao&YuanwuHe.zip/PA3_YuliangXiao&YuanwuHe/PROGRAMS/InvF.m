% compute inverse of frame (R, p)
% Input: homogeneous representation of frame F
% Output: invR is inverse of rotation matrix R and invP is the translation
% vector in another frame F^-1, invF is the homogeneous representation of
% inversed frame F^-1.
function [invR, invP, invF] = InvF(F)
    R = F(1:3,1:3);
    p = F(1:3,4);
    d = det(R);
    if ((d <0.999) | (d >1.001))
      fprintf(1,'Error: the argument R is not a rotation matrix. Determinent is %f, should be 1.0\n',d);
      error('aborting');
    end
    invR = R';
    invP = -R' * p;
    invF = FrameHomo(invR, invP);
end