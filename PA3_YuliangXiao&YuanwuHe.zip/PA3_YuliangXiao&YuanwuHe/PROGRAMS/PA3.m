clear all
clc
debug = ['A','B','C','D','E','F'];
unknown = ['G','H','J'];
% create OUTPUTS folder
mkdir('OUTPUTS');
% iterate all testing files
for i=1:length(debug)
    k = 'Debug';
    x = debug(i);
    main(x, k);
end

for j = 1:length(unknown)
    k = 'Unknown';
    x = unknown(j);
    main(x, k);
end

function main(a,b)
    %%% read mesh file
    bodySur = importdata('Problem3Mesh.sur');
    nVertices = bodySur(1);
    nTriangles = bodySur(2+nVertices*3);
    dVertices = bodySur(2:1+nVertices*3);
    dTriangles = bodySur(3+nVertices*3:size(bodySur,1));
    data_V = [];
    data_T = [];
    en = 0;
    % adjust input file to get xyz coordinate of vertex in CT coordinates
    for i=1:nVertices
        start = en + 1;
        en = i * 3;
        data = (dVertices(start:en))';
        data_V = [data_V; data];
    end
    % adjust input file to get Vertex indices of the three vertices for each triangle, followed by triangle indices for the three neighbor triangles.opposite to the three vertices
    en1 = 0;
    for i=1:nTriangles
        start1 = en1 + 1;
        en1 = i * 6;
        data1 = (dTriangles(start1:en1))';
        data_T = [data_T; data1];
    end

    %%% read body frame A
    bodyA = importdata('Problem3-BodyA.txt');
    nMarkers_A = str2double(bodyA.textdata{1}(1));
    data_A = bodyA.data;
    data_Marker_A = data_A(1:nMarkers_A,:);
    Ptip_A = data_A(nMarkers_A + 1,:);

    %%% read body frame B
    bodyB = importdata('Problem3-BodyB.txt');
    nMarkers_B = str2double(bodyB.textdata{1}(1));
    data_B = bodyB.data;
    data_Marker_B = data_B(1:nMarkers_B,:);
    Ptip_B = data_B(nMarkers_B + 1,:);

    %%% read sample frame
    filename1 = ['PA3-',a,'-',b,'-SampleReadingsTest.txt'];
    sampleF = importdata(filename1);
    data_F = sampleF.data;
    nSample = str2double(sampleF.textdata{1});
    nFrame = str2double(sampleF.textdata{2});
    en = 0;
    Fas = cell(nFrame,1);
    Fbs = cell(nFrame,1);
    dks = [];
    % for each frame, read ak and bk to compute FAk and FBk by using 3D to 3D registration
    for i = 1:nFrame
        en = nSample*(i-1);
        start = en + 1;
        en = en + nMarkers_A;
        data_a = data_F(start:en,:);
        data_b = data_F(en+1:en+nMarkers_B, :);
        data_d = data_F(en+nMarkers_B + 1 : nSample*i,:);
        Fa = T2TR(data_Marker_A, data_a);
        Fb = T2TR(data_Marker_B, data_b);
        Fas{i} = Fa;
        Fbs{i} = Fb;
        [~,~,invFb] = InvF(Fb);
        [~,~,FrameTr] = FrameTrans(invFb, Fa);
        [~, dk] = TriDxform(FrameTr, Ptip_A');
        dks = [dks;dk'];
    end

    % Freg = I => sk = Freg * dk => sk = dk
    sks = dks;

    % find all data point of three vertex of each triangle
    ind_p = data_T(:,1) + 1;
    ind_q = data_T(:,2) + 1;
    ind_r = data_T(:,3) + 1;

    p = [];
    q = [];
    r = [];
    for i = 1:size(data_T, 1)
        p = [p; data_V(ind_p(i),:)];
        q = [q; data_V(ind_q(i),:)];
        r = [r; data_V(ind_r(i),:)];
    end
    % find closest point c and minimal distance
    [c, distance] = FindClosestPoint(sks, p, q, r);
    %%% Export data
    FULLDATA = [sks'; c'; distance'];
    file_name = ['./OUTPUTS/PA3-Generated-',a,'-',b,'-Output.txt'];
    file_name1 = [' PA3-Generated-',a,'-',b,'-Output.txt 0'];
    fileID = fopen(file_name,'wt+');
    fprintf(fileID,strcat('15, ', file_name1, '\n'));
    fprintf(fileID,'%10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',FULLDATA);
    fclose(fileID);
end