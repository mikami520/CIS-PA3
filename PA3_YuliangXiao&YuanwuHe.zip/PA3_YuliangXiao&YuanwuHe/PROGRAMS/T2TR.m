% { 3D to 3D registration algorithm
%   Input: N*3 point cloud 1, N*3 point cloud 2 
%   Output: homogeneous representation of frame F
% }
function F = T2TR(pc1, pc2)
    % transpose point cloud to N*3 matrix 
    if (size(pc1,1) == 3)
    else 
        pc1 = pc1';
    end
    if (size(pc2,1) == 3)
    else 
        pc2 = pc2';
    end
    % compute midpoint of each point cloud
    average1 = mean(pc1, 2);
    average2 = mean(pc2, 2);
    % compute transformation relative to midpoint
    a_wave = pc1 - average1;
    b_wave = pc2 - average2;
    % compute H in order to use SVD (singular value decomposition)
    H = zeros(3,3);
    for i = 1:length(pc1)
        a_ele = a_wave(:,i);
        b_ele = b_wave(:,i);
        H = H + a_ele * b_ele';
    end
    % apply SVD to obtain U, S, V
    [U, S, V] = svd(H);
    % compute rotation matrix R
    R = V * U';
    % check if R is rotation matrix (det(R) == 1)
    if (abs(det(R) - 1) < 10^-6)
        p = average2 - R * average1;
        F = FrameHomo(R, p);
    % if the determinant is -1, update R with another equation
    elseif (abs(det(R) + 1) < 10^-6)
        Vprime = [V(:,1:2) -V(:,3)];
        Rprime = Vprime * U';
        p = average2 - Rprime * average1;
        F = FrameHomo(Rprime, p);
    else
        error("There is an error when using SVD, please check and revise it !!!");
    end
end
