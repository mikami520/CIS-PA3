% { 3D points transformaton
%   Input: frame F, 3D point b
%   Output: RotVec: position of 3D point with only rotation
%           RotTransVec: position of 3D point with frame transformation
% }
function [RotVec, RotTransVec] = TriDxform(F, b)
    R = F(1:3, 1:3);
    p = F(1:3, 4);
    RotVec = R * b;
    RotTransVec = R * b + p;
end